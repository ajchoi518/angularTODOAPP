// Code goes here

  angular.module('todoApp',[]);//angular module declear,todo is the name of the module
  
 


